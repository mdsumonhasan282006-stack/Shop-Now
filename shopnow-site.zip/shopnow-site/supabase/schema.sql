-- ShopNow ডাটাবেস স্কিমা
-- Supabase Dashboard > SQL Editor এ পুরোটা কপি-পেস্ট করে "Run" চাপুন।

create extension if not exists "pgcrypto";

-- ১. পণ্যের টেবিল
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  price numeric not null,
  mrp numeric not null default 0,
  rating numeric not null default 5,
  reviews integer not null default 0,
  free_delivery boolean not null default true,
  fast_delivery boolean not null default false,
  verified boolean not null default false,
  image_url text,
  color_from text default '#2b2f36',
  color_to text default '#15171b',
  created_at timestamptz not null default now()
);

-- ২. অর্ডারের টেবিল
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  address text not null,
  items jsonb not null,
  total numeric not null,
  payment_method text not null default 'cod', -- 'cod' অথবা 'bkash'
  bkash_trx_id text,
  status text not null default 'pending', -- pending / confirmed / delivered / cancelled
  created_at timestamptz not null default now()
);

-- ৩. Row Level Security চালু করা (নিরাপত্তার জন্য বাধ্যতামূলক)
alter table products enable row level security;
alter table orders enable row level security;

-- ৪. যে কেউ (কাস্টমার) পণ্য দেখতে পারবে
create policy "public can view products"
  on products for select
  using (true);

-- ৫. শুধু লগইন করা বিক্রেতা পণ্য যোগ/এডিট/ডিলিট করতে পারবে
create policy "authenticated can manage products"
  on products for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ৬. যে কেউ অর্ডার বসাতে পারবে (লগইন ছাড়াই — কাস্টমারদের অ্যাকাউন্ট লাগবে না)
create policy "anyone can place an order"
  on orders for insert
  with check (true);

-- ৭. শুধু লগইন করা বিক্রেতা অর্ডার দেখতে ও স্ট্যাটাস আপডেট করতে পারবে
create policy "authenticated can view orders"
  on orders for select
  using (auth.role() = 'authenticated');

create policy "authenticated can update orders"
  on orders for update
  using (auth.role() = 'authenticated');

-- ৮. কিছু নমুনা পণ্য দিয়ে শুরু করা (চাইলে এই অংশ বাদ দিতে পারেন)
insert into products (title, category, price, mrp, rating, reviews, free_delivery, fast_delivery, verified, color_from, color_to)
values
  ('ওয়াটারপ্রুফ রেইনকোট সেট বাই সহ (পুরুষ) - নীল', 'পুরুষ', 699, 1290, 5.0, 9, true, false, false, '#2b2f36', '#15171b'),
  ('পুষ্টি চিনিগুড়া চাল – ১ কেজি', 'মুদিখানা', 169, 190, 5.0, 327, true, true, true, '#E7D9B0', '#C9AE6E'),
  ('জয়া স্যানিটারি ন্যাপকিন - বেল্ট সিস্টেম - ১৫ পিস', 'মহিলা', 110, 140, 4.8, 152, true, false, false, '#8FBF3F', '#5E8A22');
