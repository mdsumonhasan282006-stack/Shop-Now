import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Minus, Plus, Copy } from "lucide-react";
import { supabase, BKASH_NUMBER, STORE_NAME } from "../lib/supabase";

const PINK = "#EC1561";
const NAVY = "#1E2A78";
const taka = (n) => "৳" + Number(n || 0).toLocaleString("en-IN");

export default function Checkout({ cart, onInc, onDec, clearCart }) {
  const [products, setProducts] = useState([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [method, setMethod] = useState("cod"); // 'cod' | 'bkash'
  const [trxId, setTrxId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const ids = Object.keys(cart).filter((id) => cart[id] > 0);

  useEffect(() => {
    if (ids.length === 0) {
      setProducts([]);
      return;
    }
    supabase
      .from("products")
      .select("*")
      .in("id", ids)
      .then(({ data, error }) => {
        if (!error) setProducts(data || []);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ids.join(",")]);

  const lines = useMemo(
    () => products.map((p) => ({ p, q: cart[p.id] || 0 })).filter((l) => l.q > 0),
    [products, cart]
  );
  const total = lines.reduce((s, l) => s + l.p.price * l.q, 0);

  const placeOrder = async () => {
    setError("");
    if (!name.trim() || !phone.trim() || !address.trim()) {
      setError("অনুগ্রহ করে নাম, ফোন নম্বর ও ঠিকানা পূরণ করুন।");
      return;
    }
    if (lines.length === 0) {
      setError("আপনার কার্ট খালি।");
      return;
    }
    if (method === "bkash" && !trxId.trim()) {
      setError("bKash ট্রানজেকশন আইডি লিখুন।");
      return;
    }
    setSubmitting(true);
    const { error: insertError } = await supabase.from("orders").insert({
      customer_name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      items: lines.map((l) => ({ product_id: l.p.id, title: l.p.title, price: l.p.price, qty: l.q })),
      total,
      payment_method: method,
      bkash_trx_id: method === "bkash" ? trxId.trim() : null,
    });
    setSubmitting(false);
    if (insertError) {
      setError("অর্ডার সাবমিট করতে সমস্যা হয়েছে, আবার চেষ্টা করুন।");
      return;
    }
    clearCart();
    navigate("/order-success");
  };

  return (
    <div className="min-h-screen bg-[#F5F6FA] pb-10">
      <header className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3 text-white" style={{ background: `linear-gradient(120deg, ${PINK}, #7A0E3B)` }}>
        <Link to="/" className="flex items-center gap-1 text-sm font-medium"><ArrowLeft size={18} /> দোকানে ফিরুন</Link>
        <span className="ml-auto text-base font-extrabold">চেকআউট</span>
      </header>

      <main className="mx-auto max-w-lg p-4">
        {lines.length === 0 ? (
          <p className="py-16 text-center text-sm text-gray-400">আপনার কার্ট খালি।</p>
        ) : (
          <>
            <section className="rounded-lg border border-black/5 bg-white p-4">
              <h3 className="mb-3 text-sm font-bold" style={{ color: NAVY }}>আপনার অর্ডার</h3>
              <div className="flex flex-col gap-3">
                {lines.map(({ p, q }) => (
                  <div key={p.id} className="flex items-center gap-3 border-b border-black/5 pb-3 last:border-0 last:pb-0">
                    <div
                      className="h-12 w-12 shrink-0 rounded-md bg-cover bg-center"
                      style={
                        p.image_url
                          ? { backgroundImage: `url(${p.image_url})` }
                          : { background: `linear-gradient(135deg, ${p.color_from}, ${p.color_to})` }
                      }
                    />
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-1 text-[13px]">{p.title}</p>
                      <span className="text-sm font-bold" style={{ color: PINK }}>{taka(p.price)}</span>
                    </div>
                    <div className="flex items-center gap-2 rounded-md border border-black/10 px-1 py-1">
                      <button onClick={() => onDec(p.id)} className="flex h-6 w-6 items-center justify-center rounded bg-gray-100"><Minus size={12} /></button>
                      <span className="w-4 text-center text-sm font-semibold">{q}</span>
                      <button onClick={() => onInc(p.id)} className="flex h-6 w-6 items-center justify-center rounded bg-gray-100"><Plus size={12} /></button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-3 flex items-center justify-between border-t border-black/5 pt-3 text-sm">
                <span className="text-gray-500">সর্বমোট</span>
                <span className="text-lg font-extrabold" style={{ color: NAVY }}>{taka(total)}</span>
              </div>
            </section>

            <section className="mt-4 rounded-lg border border-black/5 bg-white p-4">
              <h3 className="mb-3 text-sm font-bold" style={{ color: NAVY }}>ডেলিভারি তথ্য</h3>
              <div className="flex flex-col gap-3">
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="আপনার নাম"
                  className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]" />
                <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="মোবাইল নম্বর (যেমন 01XXXXXXXXX)"
                  className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]" />
                <textarea value={address} onChange={(e) => setAddress(e.target.value)} placeholder="সম্পূর্ণ ঠিকানা" rows={3}
                  className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]" />
              </div>
            </section>

            <section className="mt-4 rounded-lg border border-black/5 bg-white p-4">
              <h3 className="mb-3 text-sm font-bold" style={{ color: NAVY }}>পেমেন্ট পদ্ধতি</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => setMethod("cod")}
                  className="flex-1 rounded-md border py-2 text-sm font-semibold"
                  style={method === "cod" ? { borderColor: PINK, color: PINK, background: "#FFF0F5" } : { borderColor: "#ddd", color: "#666" }}
                >
                  ক্যাশ অন ডেলিভারি
                </button>
                <button
                  onClick={() => setMethod("bkash")}
                  className="flex-1 rounded-md border py-2 text-sm font-semibold"
                  style={method === "bkash" ? { borderColor: PINK, color: PINK, background: "#FFF0F5" } : { borderColor: "#ddd", color: "#666" }}
                >
                  bKash (আগে থেকে পেমেন্ট)
                </button>
              </div>

              {method === "bkash" && (
                <div className="mt-3 rounded-md bg-[#FDF2F7] p-3 text-sm">
                  <p className="text-gray-700">
                    এই bKash নাম্বারে <b>Send Money</b> করে নিচে ট্রানজেকশন আইডি দিন:
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="rounded-md bg-white px-3 py-1.5 font-bold" style={{ color: NAVY }}>{BKASH_NUMBER}</span>
                    <button
                      onClick={() => navigator.clipboard?.writeText(BKASH_NUMBER)}
                      className="flex items-center gap-1 rounded-md border border-black/10 px-2 py-1.5 text-xs text-gray-500"
                    >
                      <Copy size={12} /> কপি
                    </button>
                  </div>
                  <input
                    value={trxId}
                    onChange={(e) => setTrxId(e.target.value)}
                    placeholder="bKash ট্রানজেকশন আইডি"
                    className="mt-3 w-full rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]"
                  />
                </div>
              )}
            </section>

            {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

            <button
              onClick={placeOrder}
              disabled={submitting}
              className="mt-4 w-full rounded-md py-3 text-sm font-semibold text-white disabled:opacity-50"
              style={{ background: PINK }}
            >
              {submitting ? "অর্ডার হচ্ছে..." : `অর্ডার সম্পন্ন করুন — ${taka(total)}`}
            </button>
            <p className="mt-2 text-center text-[11px] text-gray-400">{STORE_NAME} এ কেনাকাটার জন্য ধন্যবাদ</p>
          </>
        )}
      </main>
    </div>
  );
}
