import React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { supabase, STORE_NAME } from "../lib/supabase";

const PINK = "#EC1561";
const NAVY = "#1E2A78";

export default function SellerLogin({ session, authLoading }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  if (authLoading) return null;
  if (session) return <Navigate to="/seller/dashboard" replace />;

  const login = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const { error: loginError } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (loginError) {
      setError("লগইন ব্যর্থ — ইমেইল বা পাসওয়ার্ড ভুল।");
      return;
    }
    navigate("/seller/dashboard");
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#F5F6FA] px-6">
      <Link to="/" className="absolute left-4 top-4 flex items-center gap-1 text-sm font-medium text-gray-500">
        <ArrowLeft size={16} /> দোকানে ফিরুন
      </Link>
      <div className="w-full max-w-sm rounded-lg border border-black/5 bg-white p-6">
        <h1 className="text-lg font-extrabold" style={{ color: NAVY }}>{STORE_NAME} বিক্রেতা লগইন</h1>
        <p className="mt-1 text-xs text-gray-500">
          Supabase Dashboard থেকে তৈরি করা আপনার বিক্রেতা অ্যাকাউন্ট দিয়ে লগইন করুন।
        </p>
        <form onSubmit={login} className="mt-4 flex flex-col gap-3">
          <input
            type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ইমেইল" required
            className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]"
          />
          <input
            type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="পাসওয়ার্ড" required
            className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]"
          />
          {error && <p className="text-xs font-medium text-red-600">{error}</p>}
          <button
            type="submit" disabled={loading}
            className="mt-1 rounded-md py-2.5 text-sm font-semibold text-white disabled:opacity-50"
            style={{ background: PINK }}
          >
            {loading ? "লগইন হচ্ছে..." : "লগইন করুন"}
          </button>
        </form>
      </div>
    </div>
  );
}
