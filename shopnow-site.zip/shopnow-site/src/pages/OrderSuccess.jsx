import React from "react";
import { Link } from "react-router-dom";
import { CheckCircle2 } from "lucide-react";

const PINK = "#EC1561";
const TEAL = "#0EA5A0";
const NAVY = "#1E2A78";

export default function OrderSuccess() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#F5F6FA] px-6 text-center">
      <CheckCircle2 size={56} color={TEAL} />
      <h1 className="mt-4 text-xl font-extrabold" style={{ color: NAVY }}>অর্ডার সফলভাবে সম্পন্ন হয়েছে!</h1>
      <p className="mt-2 max-w-sm text-sm text-gray-500">
        আপনার অর্ডারটি আমরা পেয়েছি। শীঘ্রই আপনার দেওয়া নম্বরে যোগাযোগ করা হবে।
      </p>
      <Link to="/" className="mt-6 rounded-md px-5 py-2.5 text-sm font-semibold text-white" style={{ background: PINK }}>
        কেনাকাটা চালিয়ে যান
      </Link>
    </div>
  );
}
