import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Search, ShoppingCart, Star, Truck, Store as StoreIcon, Home, MessageCircle,
  User, Plus, Minus,
} from "lucide-react";
import { supabase, STORE_NAME } from "../lib/supabase";

const PINK = "#EC1561";
const TEAL = "#0EA5A0";
const NAVY = "#1E2A78";

const taka = (n) => "৳" + Number(n || 0).toLocaleString("en-IN");
const discountOf = (price, mrp) => (mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0);

function ProductCard({ p, qty, onAdd, onInc, onDec }) {
  return (
    <div className="overflow-hidden rounded-lg border border-black/5 bg-white">
      <div
        className="relative h-32 w-full bg-cover bg-center"
        style={
          p.image_url
            ? { backgroundImage: `url(${p.image_url})` }
            : { background: `linear-gradient(135deg, ${p.color_from}, ${p.color_to})` }
        }
      >
        {p.free_delivery && (
          <span className="absolute bottom-2 left-2 flex items-center gap-1 rounded bg-[#E9FBF6] px-1.5 py-0.5 text-[10px] font-semibold text-[#0EA5A0]">
            <Truck size={10} /> ফ্রি ডেলিভারি
          </span>
        )}
        <span className="absolute right-2 top-2 rounded bg-white/90 px-1.5 py-0.5 text-[10px] font-medium text-gray-600">
          {p.category}
        </span>
      </div>
      <div className="flex flex-col gap-1 p-3">
        <p className="line-clamp-2 min-h-[2.4em] text-[13px] leading-snug">{p.title}</p>
        <div className="flex items-baseline gap-1.5">
          <span className="text-[14px] font-extrabold" style={{ color: PINK }}>{taka(p.price)}</span>
          {p.mrp > p.price && (
            <>
              <span className="text-[11px] text-gray-400 line-through">{taka(p.mrp)}</span>
              <span className="rounded bg-[#17B26A] px-1 py-0.5 text-[10px] font-bold text-white">
                -{discountOf(p.price, p.mrp)}%
              </span>
            </>
          )}
        </div>
        <div className="flex items-center gap-1 text-[11px] text-gray-500">
          <Star size={11} fill="#F5A623" strokeWidth={0} /> {p.rating} ({p.reviews})
        </div>

        {qty > 0 ? (
          <div className="mt-2 flex items-center justify-between rounded-md border border-black/10 px-1 py-1">
            <button onClick={onDec} className="flex h-6 w-6 items-center justify-center rounded" style={{ background: PINK }}>
              <Minus size={12} color="white" />
            </button>
            <span className="text-sm font-bold" style={{ color: NAVY }}>{qty}</span>
            <button onClick={onInc} className="flex h-6 w-6 items-center justify-center rounded" style={{ background: PINK }}>
              <Plus size={12} color="white" />
            </button>
          </div>
        ) : (
          <button onClick={onAdd} className="mt-2 w-full rounded-md py-1.5 text-xs font-semibold text-white" style={{ background: PINK }}>
            কার্টে যোগ করুন
          </button>
        )}
      </div>
    </div>
  );
}

export default function Store({ cart, onInc, onDec }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [catFilter, setCatFilter] = useState("সব");
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (!active) return;
        if (!error) setProducts(data || []);
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const categories = useMemo(
    () => ["সব", ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  );

  const filtered = useMemo(
    () =>
      products.filter(
        (p) => (catFilter === "সব" || p.category === catFilter) && p.title.includes(query)
      ),
    [products, query, catFilter]
  );

  const cartCount = Object.values(cart).reduce((s, q) => s + q, 0);

  return (
    <div className="min-h-screen bg-[#F5F6FA] text-[#222]">
      <header className="sticky top-0 z-30 px-4 pb-3 pt-4 text-white" style={{ background: `linear-gradient(160deg, ${PINK}, #7A0E3B)` }}>
        <div className="mx-auto flex max-w-6xl items-center gap-2">
          <div className="flex flex-1 items-center gap-2 rounded-full bg-white px-4 py-2.5">
            <Search size={16} className="text-gray-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`${STORE_NAME} এ খুঁজুন...`}
              className="flex-1 bg-transparent text-sm text-[#222] outline-none placeholder:text-gray-400"
            />
          </div>
          <Link to="/seller" title="বিক্রেতা প্যানেল" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/15">
            <StoreIcon size={18} />
          </Link>
        </div>
        <div className="mx-auto mt-3 flex max-w-6xl gap-2 overflow-x-auto no-scrollbar">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCatFilter(c)}
              className="shrink-0 rounded-full px-3 py-1 text-xs font-semibold"
              style={catFilter === c ? { background: "white", color: PINK } : { background: "rgba(255,255,255,0.18)", color: "white" }}
            >
              {c}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-6xl p-4 pb-24">
        <h2 className="mb-3 text-lg font-extrabold" style={{ color: NAVY }}>
          {catFilter === "সব" ? "সব পণ্য" : catFilter}
          <span className="ml-2 text-xs font-medium text-gray-400">({filtered.length}টি)</span>
        </h2>

        {loading && <p className="py-16 text-center text-sm text-gray-400">পণ্য লোড হচ্ছে...</p>}

        {!loading && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {filtered.map((p) => (
              <ProductCard
                key={p.id}
                p={p}
                qty={cart[p.id] || 0}
                onAdd={() => onInc(p.id)}
                onInc={() => onInc(p.id)}
                onDec={() => onDec(p.id)}
              />
            ))}
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <p className="py-16 text-center text-sm text-gray-400">
            কোনো পণ্য পাওয়া যায়নি — বিক্রেতা প্যানেল থেকে পণ্য যোগ করুন।
          </p>
        )}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex items-center justify-around border-t border-black/5 bg-white py-2">
        <button className="flex flex-col items-center gap-0.5 text-[11px] font-medium" style={{ color: PINK }}>
          <Home size={20} /> হোম
        </button>
        <Link to="/seller" className="flex flex-col items-center gap-0.5 text-[11px] font-medium text-gray-400">
          <StoreIcon size={20} /> বিক্রেতা
        </Link>
        <button className="flex flex-col items-center gap-0.5 text-[11px] font-medium text-gray-400">
          <MessageCircle size={20} /> মেসেজ
        </button>
        <button
          onClick={() => navigate("/checkout")}
          className="relative flex flex-col items-center gap-0.5 text-[11px] font-medium text-gray-400"
        >
          <ShoppingCart size={20} />
          {cartCount > 0 && (
            <span className="absolute -right-2 -top-1 flex h-4 w-4 items-center justify-center rounded-full text-[9px] font-bold text-white" style={{ background: PINK }}>
              {cartCount}
            </span>
          )}
          কার্ট
        </button>
        <button className="flex flex-col items-center gap-0.5 text-[11px] font-medium text-gray-400">
          <User size={20} /> অ্যাকাউন্ট
        </button>
      </nav>
    </div>
  );
}
