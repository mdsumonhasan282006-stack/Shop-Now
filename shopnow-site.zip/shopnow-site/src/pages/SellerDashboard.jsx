import React, { useEffect, useMemo, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import {
  ArrowLeft, LayoutDashboard, Package, ClipboardList, Plus, Pencil, Trash2, X,
  Search, Truck, Star, Boxes, IndianRupee, TrendingUp, LogOut,
} from "lucide-react";
import { supabase } from "../lib/supabase";

const PINK = "#EC1561";
const TEAL = "#0EA5A0";
const NAVY = "#1E2A78";

const CATEGORIES = ["পুরুষ", "মহিলা", "মোবাইল", "ঘড়ি", "মুদিখানা", "ইলেকট্রনিক্স"];
const SWATCHES = [
  ["#2b2f36", "#15171b"], ["#E7D9B0", "#C9AE6E"], ["#8FBF3F", "#5E8A22"],
  ["#F3B6C6", "#E4809E"], ["#2E3B4E", "#161D26"], ["#4A3B2A", "#2A2015"],
];

const taka = (n) => "৳" + Number(n || 0).toLocaleString("en-IN");
const discountOf = (price, mrp) => (mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0);

function StatCard({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="rounded-lg border border-black/5 bg-white p-4">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wide text-gray-400">{label}</span>
        <Icon size={16} style={{ color }} />
      </div>
      <div className="mt-2 text-2xl font-extrabold" style={{ color: NAVY }}>{value}</div>
      {sub && <div className="mt-1 text-[11px] text-gray-500">{sub}</div>}
    </div>
  );
}

function ProductForm({ initial, onClose, onSaved }) {
  const [f, setF] = useState(
    initial || {
      title: "", category: CATEGORIES[0], price: "", mrp: "", rating: 5, reviews: 0,
      free_delivery: true, fast_delivery: false, verified: false,
      color_from: SWATCHES[0][0], color_to: SWATCHES[0][1], image_url: null,
    }
  );
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(initial?.image_url || null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const valid = f.title.trim() && Number(f.price) > 0;

  const onFile = (e) => {
    const chosen = e.target.files?.[0];
    if (!chosen) return;
    setFile(chosen);
    setPreview(URL.createObjectURL(chosen));
  };

  const save = async () => {
    setErr("");
    setSaving(true);
    try {
      let image_url = f.image_url || null;
      if (file) {
        const path = `${Date.now()}-${file.name}`;
        const { error: upErr } = await supabase.storage.from("products").upload(path, file);
        if (upErr) throw upErr;
        const { data } = supabase.storage.from("products").getPublicUrl(path);
        image_url = data.publicUrl;
      }
      const payload = {
        title: f.title.trim(),
        category: f.category,
        price: Number(f.price) || 0,
        mrp: Number(f.mrp) || 0,
        rating: Number(f.rating) || 5,
        reviews: Number(f.reviews) || 0,
        free_delivery: f.free_delivery,
        fast_delivery: f.fast_delivery,
        verified: f.verified,
        color_from: f.color_from,
        color_to: f.color_to,
        image_url,
      };
      if (initial) {
        const { error } = await supabase.from("products").update(payload).eq("id", initial.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("products").insert(payload);
        if (error) throw error;
      }
      onSaved();
    } catch (e) {
      setErr("সেভ করতে সমস্যা হয়েছে — আবার চেষ্টা করুন।");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative max-h-[90vh] w-full max-w-md overflow-y-auto rounded-t-2xl bg-white shadow-xl sm:rounded-lg">
        <div className="sticky top-0 flex items-center justify-between border-b border-black/5 bg-white px-5 py-4">
          <h3 className="text-lg font-bold" style={{ color: NAVY }}>{initial ? "পণ্য সম্পাদনা" : "নতুন পণ্য যোগ করুন"}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-black"><X size={20} /></button>
        </div>

        <div className="flex flex-col gap-4 px-5 py-5">
          <div
            className="h-28 w-full rounded-lg bg-cover bg-center"
            style={preview ? { backgroundImage: `url(${preview})` } : { background: `linear-gradient(135deg, ${f.color_from}, ${f.color_to})` }}
          />
          <label className="flex flex-col gap-1">
            <span className="text-xs font-medium text-gray-500">পণ্যের ছবি আপলোড করুন (ঐচ্ছিক)</span>
            <input type="file" accept="image/*" onChange={onFile} className="text-xs" />
          </label>
          {!preview && (
            <div>
              <span className="mb-1.5 block text-xs font-medium text-gray-500">অথবা একটি রঙ বেছে নিন</span>
              <div className="flex flex-wrap gap-2">
                {SWATCHES.map(([a, b], i) => (
                  <button key={i} onClick={() => setF((s) => ({ ...s, color_from: a, color_to: b }))}
                    className="h-8 w-8 rounded-full border-2"
                    style={{ background: `linear-gradient(135deg, ${a}, ${b})`, borderColor: f.color_from === a ? PINK : "transparent" }} />
                ))}
              </div>
            </div>
          )}

          <label className="flex flex-col gap-1">
            <span className="text-xs font-medium text-gray-500">পণ্যের নাম</span>
            <input value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="যেমন: কটন ফরমাল শার্ট - স্লিম ফিট"
              className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]" />
          </label>

          <label className="flex flex-col gap-1">
            <span className="text-xs font-medium text-gray-500">ক্যাটেগরি</span>
            <select value={f.category} onChange={(e) => set("category", e.target.value)}
              className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]">
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>

          <div className="grid grid-cols-2 gap-4">
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-gray-500">বিক্রয় মূল্য (৳)</span>
              <input type="number" value={f.price} onChange={(e) => set("price", e.target.value)}
                className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-gray-500">মূল দাম / MRP (৳)</span>
              <input type="number" value={f.mrp} onChange={(e) => set("mrp", e.target.value)}
                className="rounded-md border border-black/10 px-3 py-2 text-sm outline-none focus:border-[#EC1561]" />
            </label>
          </div>

          <div className="flex flex-wrap gap-4 pt-1">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={f.free_delivery} onChange={(e) => set("free_delivery", e.target.checked)} /> ফ্রি ডেলিভারি
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={f.fast_delivery} onChange={(e) => set("fast_delivery", e.target.checked)} /> দ্রুত ডেলিভারি
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={f.verified} onChange={(e) => set("verified", e.target.checked)} /> যাচাইকৃত বিক্রেতা
            </label>
          </div>

          {err && <p className="text-xs font-medium text-red-600">{err}</p>}
        </div>

        <div className="sticky bottom-0 flex justify-end gap-3 border-t border-black/5 bg-white px-5 py-4">
          <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-black">বাতিল</button>
          <button disabled={!valid || saving} onClick={save}
            className="rounded-md px-4 py-2 text-sm font-semibold text-white disabled:opacity-40" style={{ background: PINK }}>
            {saving ? "সেভ হচ্ছে..." : initial ? "আপডেট করুন" : "পণ্য যোগ করুন"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ProductsTab() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [catFilter, setCatFilter] = useState("সব");
  const [modal, setModal] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const load = () => {
    setLoading(true);
    supabase.from("products").select("*").order("created_at", { ascending: false }).then(({ data, error }) => {
      if (!error) setProducts(data || []);
      setLoading(false);
    });
  };
  useEffect(load, []);

  const filtered = useMemo(
    () => products.filter((p) => (catFilter === "সব" || p.category === catFilter) && p.title.includes(query)),
    [products, query, catFilter]
  );

  const deleteProduct = async (id) => {
    await supabase.from("products").delete().eq("id", id);
    setConfirmDelete(null);
    load();
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold" style={{ color: NAVY }}>পণ্যসমূহ</h1>
          <p className="mt-0.5 text-sm text-gray-500">{products.length}টি পণ্য দোকানে আছে</p>
        </div>
        <button onClick={() => setModal("new")} className="flex items-center gap-1.5 rounded-md px-4 py-2 text-sm font-semibold text-white" style={{ background: PINK }}>
          <Plus size={15} /> পণ্য যোগ করুন
        </button>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-2 rounded-md border border-black/10 bg-white px-3 py-2">
          <Search size={14} className="text-gray-400" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="পণ্য খুঁজুন..." className="w-40 bg-transparent text-sm outline-none" />
        </div>
        {["সব", ...CATEGORIES].map((c) => (
          <button key={c} onClick={() => setCatFilter(c)} className="rounded-full border px-3 py-1 text-xs font-medium"
            style={catFilter === c ? { background: PINK, borderColor: PINK, color: "white" } : { borderColor: "#ddd", color: "#666" }}>
            {c}
          </button>
        ))}
      </div>

      {loading && <p className="py-14 text-center text-sm text-gray-400">লোড হচ্ছে...</p>}

      {!loading && (
        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <div key={p.id} className="overflow-hidden rounded-lg border border-black/5 bg-white">
              <div
                className="relative h-32 w-full bg-cover bg-center"
                style={p.image_url ? { backgroundImage: `url(${p.image_url})` } : { background: `linear-gradient(135deg, ${p.color_from}, ${p.color_to})` }}
              >
                {p.free_delivery && (
                  <span className="absolute bottom-2 left-2 flex items-center gap-1 rounded bg-[#E9FBF6] px-1.5 py-0.5 text-[10px] font-semibold text-[#0EA5A0]">
                    <Truck size={10} /> ফ্রি ডেলিভারি
                  </span>
                )}
                <span className="absolute right-2 top-2 rounded bg-white/90 px-1.5 py-0.5 text-[10px] font-medium text-gray-600">{p.category}</span>
              </div>
              <div className="flex flex-col gap-1 p-3">
                <p className="line-clamp-2 text-[13px] leading-snug">{p.title}</p>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-[14px] font-extrabold" style={{ color: PINK }}>{taka(p.price)}</span>
                  {p.mrp > p.price && (
                    <>
                      <span className="text-[11px] text-gray-400 line-through">{taka(p.mrp)}</span>
                      <span className="rounded bg-[#17B26A] px-1 py-0.5 text-[10px] font-bold text-white">-{discountOf(p.price, p.mrp)}%</span>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-1 text-[11px] text-gray-500">
                  <Star size={11} fill="#F5A623" strokeWidth={0} /> {p.rating} ({p.reviews})
                </div>
                <div className="mt-2 flex justify-end gap-2 border-t border-black/5 pt-2">
                  <button onClick={() => setModal(p)} className="rounded border border-black/10 p-1.5 hover:border-[#EC1561] hover:text-[#EC1561]"><Pencil size={13} /></button>
                  <button onClick={() => setConfirmDelete(p)} className="rounded border border-black/10 p-1.5 hover:border-red-500 hover:text-red-500"><Trash2 size={13} /></button>
                </div>
              </div>
            </div>
          ))}
          {filtered.length === 0 && <p className="col-span-full py-14 text-center text-sm text-gray-400">কোনো পণ্য পাওয়া যায়নি।</p>}
        </div>
      )}

      {(modal === "new" || (modal && modal !== "new")) && (
        <ProductForm initial={modal === "new" ? null : modal} onClose={() => setModal(null)} onSaved={() => { setModal(null); load(); }} />
      )}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setConfirmDelete(null)} />
          <div className="relative w-full max-w-sm rounded-lg bg-white p-5 shadow-xl">
            <h3 className="text-lg font-bold" style={{ color: NAVY }}>পণ্য মুছে ফেলবেন?</h3>
            <p className="mt-2 text-sm text-gray-500">"{confirmDelete.title}" স্থায়ীভাবে মুছে যাবে।</p>
            <div className="mt-5 flex justify-end gap-3">
              <button onClick={() => setConfirmDelete(null)} className="text-sm font-medium text-gray-500 hover:text-black">বাতিল</button>
              <button onClick={() => deleteProduct(confirmDelete.id)} className="rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700">মুছুন</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const STATUS_OPTIONS = ["pending", "confirmed", "delivered", "cancelled"];
const STATUS_LABEL = { pending: "অপেক্ষমান", confirmed: "নিশ্চিত", delivered: "ডেলিভারি হয়েছে", cancelled: "বাতিল" };

function OrdersTab() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    supabase.from("orders").select("*").order("created_at", { ascending: false }).then(({ data, error }) => {
      if (!error) setOrders(data || []);
      setLoading(false);
    });
  };
  useEffect(load, []);

  const updateStatus = async (id, status) => {
    await supabase.from("orders").update({ status }).eq("id", id);
    load();
  };

  return (
    <div>
      <h1 className="text-2xl font-extrabold" style={{ color: NAVY }}>অর্ডারসমূহ</h1>
      <p className="mt-0.5 text-sm text-gray-500">{orders.length}টি অর্ডার এসেছে</p>

      {loading && <p className="py-14 text-center text-sm text-gray-400">লোড হচ্ছে...</p>}

      {!loading && (
        <div className="mt-4 flex flex-col gap-3">
          {orders.map((o) => (
            <div key={o.id} className="rounded-lg border border-black/5 bg-white p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-bold" style={{ color: NAVY }}>{o.customer_name}</p>
                  <p className="text-xs text-gray-500">{o.phone} · {o.address}</p>
                </div>
                <select
                  value={o.status}
                  onChange={(e) => updateStatus(o.id, e.target.value)}
                  className="rounded-md border border-black/10 px-2 py-1 text-xs font-medium"
                >
                  {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
                </select>
              </div>
              <div className="mt-3 flex flex-col gap-1 border-t border-black/5 pt-3">
                {(o.items || []).map((it, i) => (
                  <div key={i} className="flex justify-between text-xs text-gray-600">
                    <span>{it.title} × {it.qty}</span>
                    <span>{taka(it.price * it.qty)}</span>
                  </div>
                ))}
              </div>
              <div className="mt-2 flex items-center justify-between border-t border-black/5 pt-2 text-sm">
                <span className="text-gray-500">
                  {o.payment_method === "bkash" ? `bKash (ট্রানজেকশন: ${o.bkash_trx_id || "-"})` : "ক্যাশ অন ডেলিভারি"}
                </span>
                <span className="font-extrabold" style={{ color: PINK }}>{taka(o.total)}</span>
              </div>
            </div>
          ))}
          {orders.length === 0 && <p className="py-14 text-center text-sm text-gray-400">এখনো কোনো অর্ডার আসেনি।</p>}
        </div>
      )}
    </div>
  );
}

export default function SellerDashboard({ session, authLoading }) {
  const [tab, setTab] = useState("dashboard");
  const [stats, setStats] = useState({ count: 0, avg: 0, delivery: 0, verified: 0, orders: 0 });
  const navigate = useNavigate();

  useEffect(() => {
    if (!session) return;
    supabase.from("products").select("*").then(({ data }) => {
      const products = data || [];
      setStats((s) => ({
        ...s,
        count: products.length,
        avg: products.length ? Math.round(products.reduce((sum, p) => sum + p.price, 0) / products.length) : 0,
        delivery: products.filter((p) => p.free_delivery).length,
        verified: products.filter((p) => p.verified).length,
      }));
    });
    supabase.from("orders").select("id", { count: "exact", head: true }).then(({ count }) => {
      setStats((s) => ({ ...s, orders: count || 0 }));
    });
  }, [session]);

  if (authLoading) return null;
  if (!session) return <Navigate to="/seller" replace />;

  const logout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const NAV = [
    { key: "dashboard", label: "ড্যাশবোর্ড", icon: LayoutDashboard },
    { key: "products", label: "পণ্যসমূহ", icon: Package },
    { key: "orders", label: "অর্ডার", icon: ClipboardList },
  ];

  return (
    <div className="min-h-screen bg-[#F5F6FA]">
      <header className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3 text-white" style={{ background: `linear-gradient(120deg, ${PINK}, #7A0E3B)` }}>
        <button onClick={() => navigate("/")} className="flex items-center gap-1 text-sm font-medium"><ArrowLeft size={18} /> দোকান দেখুন</button>
        <span className="ml-auto text-base font-extrabold">বিক্রেতা প্যানেল</span>
        <button onClick={logout} className="flex items-center gap-1 text-sm font-medium"><LogOut size={16} /></button>
      </header>

      <div className="mx-auto max-w-6xl">
        <div className="border-b border-black/5 bg-white px-4">
          <div className="mx-auto flex max-w-6xl gap-1 py-1">
            {NAV.map((n) => (
              <button key={n.key} onClick={() => setTab(n.key)}
                className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-medium"
                style={tab === n.key ? { background: PINK, color: "white" } : { color: "#555" }}>
                <n.icon size={15} /> {n.label}
              </button>
            ))}
          </div>
        </div>

        <main className="p-4 md:p-6">
          {tab === "dashboard" && (
            <div>
              <h1 className="text-2xl font-extrabold" style={{ color: NAVY }}>ড্যাশবোর্ড</h1>
              <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
                <StatCard icon={Boxes} label="মোট পণ্য" value={stats.count} color={PINK} />
                <StatCard icon={IndianRupee} label="গড় মূল্য" value={taka(stats.avg)} color={TEAL} />
                <StatCard icon={Truck} label="ফ্রি ডেলিভারি" value={stats.delivery} sub="পণ্যের সংখ্যা" color={PINK} />
                <StatCard icon={ClipboardList} label="মোট অর্ডার" value={stats.orders} color={TEAL} />
              </div>
              <button onClick={() => setTab("products")} className="mt-6 flex items-center gap-2 rounded-md px-4 py-2.5 text-sm font-semibold text-white" style={{ background: PINK }}>
                <Plus size={16} /> পণ্য যোগ করুন
              </button>
            </div>
          )}
          {tab === "products" && <ProductsTab />}
          {tab === "orders" && <OrdersTab />}
        </main>
      </div>
    </div>
  );
}
