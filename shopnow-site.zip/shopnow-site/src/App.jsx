import React, { useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import { supabase } from "./lib/supabase";
import Store from "./pages/Store.jsx";
import Checkout from "./pages/Checkout.jsx";
import OrderSuccess from "./pages/OrderSuccess.jsx";
import SellerLogin from "./pages/SellerLogin.jsx";
import SellerDashboard from "./pages/SellerDashboard.jsx";

export default function App() {
  const [cart, setCart] = useState({}); // { productId: qty }
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  const inc = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const dec = (id) => setCart((c) => ({ ...c, [id]: Math.max(0, (c[id] || 0) - 1) }));
  const clearCart = () => setCart({});

  return (
    <Routes>
      <Route path="/" element={<Store cart={cart} onInc={inc} onDec={dec} />} />
      <Route path="/checkout" element={<Checkout cart={cart} onInc={inc} onDec={dec} clearCart={clearCart} />} />
      <Route path="/order-success" element={<OrderSuccess />} />
      <Route
        path="/seller"
        element={<SellerLogin session={session} authLoading={authLoading} />}
      />
      <Route
        path="/seller/dashboard"
        element={<SellerDashboard session={session} authLoading={authLoading} />}
      />
    </Routes>
  );
}
